
#ifndef __PIT_H
#define __PIT_H
#include"common.h"

//void pit_init(void);
void Timer2_IQR_handle(void);

#endif
