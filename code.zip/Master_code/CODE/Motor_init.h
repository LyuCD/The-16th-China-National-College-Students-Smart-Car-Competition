
#ifndef __MOTOR_INIT_H
#define __MOTOR_INIT_H

 void Motor_Init(void);
 void Set_Pwm(int motor_a,int motor_b,int motor_c,int motor_d);


 #endif
