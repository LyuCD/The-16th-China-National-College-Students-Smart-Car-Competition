
#ifndef __PIT_H
#define __PIT_H
#include"common.h"

//void pit_init(void);
void pit0(void);

#endif
