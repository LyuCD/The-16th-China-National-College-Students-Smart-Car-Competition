#include <Recognition.h>

uint8 threshold = 0;
//��ʼ��ͼƬ

uint8 site[Ra_Max][2] = { 0 };
void binarization(uint8(*p)[COL])
{
	int i, j, nm;
	uint16  g[256] = { 0 };
	uint8 threshold = 0;
	float n;
	float sum = 0;				//�Ҷ���ֵ
	float sums = 0;
	uint16 num = 0;				//�������������
	uint16 nums = 0;
	uint16 Grey_max, Grey_min;
	uint8 c = col, r = row;
	num = (c - 4 - (c - 4) / 2) * (r - 4 - (r - 4) / 2);
	for (i = 2; i < row - 2; i += 2)
		for (j = 2; j < col - 2; j += 2)
		{
			g[p[2 * i][2 * j]]++;
			sum += p[2 * i][2 * j];
		}
	//������С�Ҷ�ֵ
	for (Grey_min = 0; !g[Grey_min]; Grey_min++);

	//�������Ҷ�ֵ
	for (Grey_max = 255; !g[Grey_max]; Grey_max--);

	if (Grey_min + 70 < Grey_max)
	{

		sums = g[Grey_min] * Grey_min;
		nums = g[Grey_min];

		for (i = Grey_min + 1, threshold = Grey_min, nm = 0; i < Grey_max; i++)
		{
			sums += g[i] * i;
			nums += g[i];

			n = sums / nums * sums + (sum - sums) / (num - nums) * (sum - sums);

			if (n > nm)
			{
				threshold = i;
				nm = n;
			}
		}
	}
	else {
		return;
	}
	//cout << "threshold=" << threshold << endl;
	//���-��ͷ�Χ����

	//��ֵ��
	for (j = 2; j < col - 2; j++)
		for (i = 2; i < row - 2; i++)
		{
			if (p[ROW - 1 - 2 * i][2 * j] < threshold)
			{
				p[i][j] = 0;
			}
			else
			{
				p[i][j] = 1;
			}
		}

	//���ӱ߿�
	for (i = 0; i < row; i++)
	{
		p[i][0] = 0;
		p[i][1] = 0;
		p[i][col - 1] = 0;
		p[i][col - 2] = 0;
	}
	for (j = 2; j < col - 2; j++)
	{
		p[0][j] = 0;
		p[1][j] = 0;
		p[row - 1][j] = 0;
		p[row - 2][j] = 0;
	}

}

uint8 nighbor_judge(uint8(*p)[COL], uint8(*line)[col], uint8 a, uint8 b, uint8 n)//�����ж�
{
	if (p[a][b])
		return 0;
	uint8 i, j;
	uint16 k = 0, c = 0;
	//����ɨ��
	do {
		for (i = 0; i < 3; i += 2)
		{
			for (j = 0; j < 2; j++)
			{
				////cout << b - 1 + j << endl;
				if (line[a - 1 + i][b - 1 + j] == n)
					continue;
				if (line[a - 1 + i][b + j] == n)
					break;
				if (p[a - 1 + i][b - 1 + j] != p[a - 1 + i][b + j])
					if (!p[a - 1 + i][b - 1 + j] && line[a - 1 + i][b - 1 + j] != n)
					{
						line[a - 1 + i][b - 1 + j] = n;
						site[k][0] = a - 1 + i;
						site[k++][1] = b - 1 + j;
					}
					else
						if (!p[a - 1 + i][b + j] && line[a - 1 + i][b + j] != n)
						{
							line[a - 1 + i][b + j] = n;
							site[k][0] = a - 1 + i;
							site[k++][1] = b + j;
						}
			}
		}
		for (j = 0; j < 3; j += 2)
		{
			for (i = 0; i < 2; i++)
			{
				if (line[a - 1 + i][b - 1 + j] == n)
					continue;
				if (line[a + i][b - 1 + j] == n)
					break;
				if (p[a - 1 + i][b - 1 + j] != p[a + i][b - 1 + j])
					if (!p[a - 1 + i][b - 1 + j] && line[a - 1 + i][b - 1 + j] != n)
					{
						line[a - 1 + i][b - 1 + j] = n;
						site[k][0] = a - 1 + i;
						site[k++][1] = b - 1 + j;
					}
					else
						if (!p[a + i][b - 1 + j] && line[a + i][b - 1 + j] != n)
						{
							line[a + i][b - 1 + j] = n;
							site[k][0] = a + i;
							site[k++][1] = b - 1 + j;
						}
			}
		}
		if (k > Ra_Max - 9)
			return 0;
		site[c][0] = 0;
		site[c++][1] = 0;
		a = site[c][0];
		b = site[c][1];
	} while (a);
	return k;
}


uint8 line_hunting(uint8(*p)[COL], uint8(*side_line)[col])//������
{
	//�����жϱ�׼Ϊ����Ϊ�׵㣬����Ϊһ���е㣬����Ѱ��ʱ������ֶ��д�������������迼��ʵ���е�

	uint8 j;
	uint16 ra = 0;

	if (p[2][col / 2])
	{
		ra = nighbor_judge(p, side_line, 1, col / 2, 2);
		//cout << "ra=" << ra << endl;
		if (ra == 0)
		{
			//�ߵ����
			if (side_line[1][col / 2] == 2)
				return 0;
		}
		else						//һ�����������бߵ�ֵ��Ѱ
		{
			return col / 2;
		}
	}
	//�������е�

	for (j = 2; j < col - 2; j++)
	{
		////cout << p[2][j] << " ";
		if (p[2][j])
		{
			ra = nighbor_judge(p, side_line, 1, j, 2);
			//cout << "ra=" << ra << endl;
			if (!ra)
				continue;
			else
				return 1;
		}
	}

	return  0;

}


void flip(uint8(*image)[COL], uint8(*side_line)[col], uint8* mide_line)
{
	uint8 i, j, k;

	for (i = 1; i < row - 1; i++)
	{
		if (mide_line[i])
			side_line[i][mide_line[i]] = 3;
	}
	for (i = 0; i < row; i++)
		for (j = 0; j < col; j++)
		{
			if (side_line[i][j])
				image[i][j] = side_line[i][j];
		}
	for (i = 0; i < row / 2; i++)
		for (j = 0; j < col; j++)
		{
			k = image[i][j];
			image[i][j] = image[row - i - 1][j];
			image[row - i - 1][j] = k;
		}
	for (i = 0; i < row; i++)
		for (j = 0; j < col; j++)
		{
			image[ROW - 1 - 2 * i][COL - 1 - 2 * j] = image[row - 1 - i][col - 1 - j];
			image[ROW - 2 - 2 * i][COL - 1 - 2 * j] = image[row - 1 - i][col - 1 - j];
			image[ROW - 1 - 2 * i][COL - 2 - 2 * j] = image[row - 1 - i][col - 1 - j];
			image[ROW - 2 - 2 * i][COL - 2 - 2 * j] = image[row - 1 - i][col - 1 - j];
		}
}

int8 mid_value(uint8* mid_line, uint8(*side_line)[col])
{
	uint8 i, j;
	uint8 max;
	float m;
	uint16 d;
	uint8 right[row] = { 0 }, left[row] = { 0 };	//��ֹͼƬ��ʼӰ�죬�����ɸĻ�

	for(i=1;side_line[1][i]!=2;i++);
	for(j=col-2;side_line[1][j]!=2;j--);
	mid_line[1]=(i+j)/2;

	for(i=2;side_line[i][mid_line[i-1]]!=2;i++)
	{
	    for(j=mid_line[i-1];side_line[i][j]!=2;j--);
	    mid_line[i]=j;
	    for(j=mid_line[i-1];side_line[i][j]!=2;j++);
	    mid_line[i]=(mid_line[i]+j)/2;
	}
	mid_max=i;

	if (mid_max)
		max = mid_max - 1;
	else {
		return 0;
	}
	for (i = 2, d = 0, m = 0; i < max; i++)
	{
		for (j = mid_line[i]; j < col - 1; j++)
			if (side_line[i][j] == 2)
				right[i] = j;
		for (j = mid_line[i]; j; j--)
		{
			if (side_line[i][j] == 2)
				left[i] = j;
		}
		d += (right[i] - left[i]);
		m += mid_line[i] * (right[i] - left[i]);
	}
	//	    ips114_showstr(0,5,"m");
	//	              ips114_showint16(8*13,5,m);
	//	               ips114_showstr(0,6,"d");
	//	              ips114_showint16(8*13,6,d);
	m /= d;
	m -= col / 2;
	//	    ips114_showstr(0,7,"ang");
	//	              ips114_showint16(8*13,7,m);

	angular_c = m;
	return 1;
}
